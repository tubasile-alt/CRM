--
-- PostgreSQL database dump
--

\restrict hRnEjLwxhdrICI3zvIbjXP0rY82HhNZIfRCyvTn1FPuLTs9ghdgJIYmaYL0JoOC

-- Dumped from database version 16.9 (415ebe8)
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointment; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.appointment (
    id integer NOT NULL,
    patient_id integer NOT NULL,
    doctor_id integer NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    status character varying(20),
    appointment_type character varying(20),
    notes text,
    waiting boolean,
    checked_in_time timestamp without time zone,
    room character varying(50),
    created_at timestamp without time zone
);


ALTER TABLE public.appointment OWNER TO neondb_owner;

--
-- Name: appointment_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.appointment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointment_id_seq OWNER TO neondb_owner;

--
-- Name: appointment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.appointment_id_seq OWNED BY public.appointment.id;


--
-- Name: chat_message; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.chat_message (
    id integer NOT NULL,
    sender_id integer NOT NULL,
    recipient_id integer NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone,
    read boolean
);


ALTER TABLE public.chat_message OWNER TO neondb_owner;

--
-- Name: chat_message_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.chat_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_message_id_seq OWNER TO neondb_owner;

--
-- Name: chat_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.chat_message_id_seq OWNED BY public.chat_message.id;


--
-- Name: cosmetic_procedure_plan; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.cosmetic_procedure_plan (
    id integer NOT NULL,
    note_id integer NOT NULL,
    procedure_name character varying(100) NOT NULL,
    planned_value numeric(10,2),
    final_budget numeric(10,2),
    was_performed boolean,
    performed_date timestamp without time zone,
    follow_up_months integer,
    created_at timestamp without time zone
);


ALTER TABLE public.cosmetic_procedure_plan OWNER TO neondb_owner;

--
-- Name: cosmetic_procedure_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.cosmetic_procedure_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cosmetic_procedure_plan_id_seq OWNER TO neondb_owner;

--
-- Name: cosmetic_procedure_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.cosmetic_procedure_plan_id_seq OWNED BY public.cosmetic_procedure_plan.id;


--
-- Name: doctor_preference; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.doctor_preference (
    id integer NOT NULL,
    user_id integer NOT NULL,
    color character varying(7),
    layer_enabled boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.doctor_preference OWNER TO neondb_owner;

--
-- Name: doctor_preference_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.doctor_preference_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doctor_preference_id_seq OWNER TO neondb_owner;

--
-- Name: doctor_preference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.doctor_preference_id_seq OWNED BY public.doctor_preference.id;


--
-- Name: follow_up_reminder; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.follow_up_reminder (
    id integer NOT NULL,
    patient_id integer NOT NULL,
    procedure_name character varying(100) NOT NULL,
    scheduled_date date NOT NULL,
    reminder_type character varying(50),
    status character varying(20),
    notes text,
    created_at timestamp without time zone
);


ALTER TABLE public.follow_up_reminder OWNER TO neondb_owner;

--
-- Name: follow_up_reminder_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.follow_up_reminder_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.follow_up_reminder_id_seq OWNER TO neondb_owner;

--
-- Name: follow_up_reminder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.follow_up_reminder_id_seq OWNED BY public.follow_up_reminder.id;


--
-- Name: hair_transplant; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.hair_transplant (
    id integer NOT NULL,
    note_id integer NOT NULL,
    norwood_classification character varying(20),
    previous_transplant character varying(10),
    transplant_location character varying(50),
    case_type character varying(50),
    number_of_surgeries integer,
    body_hair_needed boolean,
    eyebrow_transplant boolean,
    beard_transplant boolean,
    frontal_transplant boolean,
    crown_transplant boolean,
    complete_transplant boolean,
    complete_with_body_hair boolean,
    surgical_planning text,
    clinical_conduct text,
    created_at timestamp without time zone
);


ALTER TABLE public.hair_transplant OWNER TO neondb_owner;

--
-- Name: hair_transplant_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.hair_transplant_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hair_transplant_id_seq OWNER TO neondb_owner;

--
-- Name: hair_transplant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.hair_transplant_id_seq OWNED BY public.hair_transplant.id;


--
-- Name: indication; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.indication (
    id integer NOT NULL,
    note_id integer NOT NULL,
    procedure_id integer NOT NULL,
    indicated boolean,
    performed boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.indication OWNER TO neondb_owner;

--
-- Name: indication_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.indication_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.indication_id_seq OWNER TO neondb_owner;

--
-- Name: indication_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.indication_id_seq OWNED BY public.indication.id;


--
-- Name: message_read; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.message_read (
    id integer NOT NULL,
    message_id integer NOT NULL,
    user_id integer NOT NULL,
    read_at timestamp without time zone
);


ALTER TABLE public.message_read OWNER TO neondb_owner;

--
-- Name: message_read_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.message_read_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.message_read_id_seq OWNER TO neondb_owner;

--
-- Name: message_read_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.message_read_id_seq OWNED BY public.message_read.id;


--
-- Name: note; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.note (
    id integer NOT NULL,
    patient_id integer NOT NULL,
    doctor_id integer NOT NULL,
    appointment_id integer,
    note_type character varying(50) NOT NULL,
    category character varying(50),
    content text,
    consultation_duration integer,
    created_at timestamp without time zone
);


ALTER TABLE public.note OWNER TO neondb_owner;

--
-- Name: note_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.note_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.note_id_seq OWNER TO neondb_owner;

--
-- Name: note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.note_id_seq OWNED BY public.note.id;


--
-- Name: operating_room; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.operating_room (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    capacity integer,
    created_at timestamp without time zone
);


ALTER TABLE public.operating_room OWNER TO neondb_owner;

--
-- Name: operating_room_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.operating_room_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.operating_room_id_seq OWNER TO neondb_owner;

--
-- Name: operating_room_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.operating_room_id_seq OWNED BY public.operating_room.id;


--
-- Name: patient; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.patient (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    phone character varying(20),
    email character varying(120),
    birth_date date,
    cpf character varying(14),
    address character varying(200),
    patient_type character varying(50),
    attention_note text,
    created_at timestamp without time zone
);


ALTER TABLE public.patient OWNER TO neondb_owner;

--
-- Name: patient_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.patient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_id_seq OWNER TO neondb_owner;

--
-- Name: patient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.patient_id_seq OWNED BY public.patient.id;


--
-- Name: patient_tag; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.patient_tag (
    id integer NOT NULL,
    patient_id integer NOT NULL,
    tag_id integer NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.patient_tag OWNER TO neondb_owner;

--
-- Name: patient_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.patient_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patient_tag_id_seq OWNER TO neondb_owner;

--
-- Name: patient_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.patient_tag_id_seq OWNED BY public.patient_tag.id;


--
-- Name: payment; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.payment (
    id integer NOT NULL,
    appointment_id integer NOT NULL,
    patient_id integer NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    payment_method character varying(50) NOT NULL,
    installments integer,
    status character varying(20),
    procedures json,
    consultation_type character varying(50),
    created_at timestamp without time zone,
    paid_at timestamp without time zone
);


ALTER TABLE public.payment OWNER TO neondb_owner;

--
-- Name: payment_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_id_seq OWNER TO neondb_owner;

--
-- Name: payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.payment_id_seq OWNED BY public.payment.id;


--
-- Name: procedure; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.procedure (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    created_at timestamp without time zone
);


ALTER TABLE public.procedure OWNER TO neondb_owner;

--
-- Name: procedure_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.procedure_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procedure_id_seq OWNER TO neondb_owner;

--
-- Name: procedure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.procedure_id_seq OWNED BY public.procedure.id;


--
-- Name: surgery; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.surgery (
    id integer NOT NULL,
    date date NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    patient_id integer,
    patient_name character varying(100) NOT NULL,
    procedure_id integer,
    procedure_name character varying(200) NOT NULL,
    doctor_id integer NOT NULL,
    operating_room_id integer NOT NULL,
    status character varying(20),
    notes text,
    created_by integer NOT NULL,
    updated_by integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.surgery OWNER TO neondb_owner;

--
-- Name: surgery_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.surgery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.surgery_id_seq OWNER TO neondb_owner;

--
-- Name: surgery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.surgery_id_seq OWNED BY public.surgery.id;


--
-- Name: tag; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tag (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    color character varying(7),
    created_at timestamp without time zone
);


ALTER TABLE public.tag OWNER TO neondb_owner;

--
-- Name: tag_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tag_id_seq OWNER TO neondb_owner;

--
-- Name: tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tag_id_seq OWNED BY public.tag.id;


--
-- Name: transplant_image; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.transplant_image (
    id integer NOT NULL,
    hair_transplant_id integer NOT NULL,
    image_type character varying(50) NOT NULL,
    file_path character varying(255) NOT NULL,
    description text,
    created_at timestamp without time zone
);


ALTER TABLE public.transplant_image OWNER TO neondb_owner;

--
-- Name: transplant_image_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.transplant_image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transplant_image_id_seq OWNER TO neondb_owner;

--
-- Name: transplant_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.transplant_image_id_seq OWNED BY public.transplant_image.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(200) NOT NULL,
    name character varying(100) NOT NULL,
    role character varying(20) NOT NULL,
    specialty character varying(50),
    created_at timestamp without time zone
);


ALTER TABLE public."user" OWNER TO neondb_owner;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO neondb_owner;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: appointment id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointment ALTER COLUMN id SET DEFAULT nextval('public.appointment_id_seq'::regclass);


--
-- Name: chat_message id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_message ALTER COLUMN id SET DEFAULT nextval('public.chat_message_id_seq'::regclass);


--
-- Name: cosmetic_procedure_plan id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cosmetic_procedure_plan ALTER COLUMN id SET DEFAULT nextval('public.cosmetic_procedure_plan_id_seq'::regclass);


--
-- Name: doctor_preference id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.doctor_preference ALTER COLUMN id SET DEFAULT nextval('public.doctor_preference_id_seq'::regclass);


--
-- Name: follow_up_reminder id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.follow_up_reminder ALTER COLUMN id SET DEFAULT nextval('public.follow_up_reminder_id_seq'::regclass);


--
-- Name: hair_transplant id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.hair_transplant ALTER COLUMN id SET DEFAULT nextval('public.hair_transplant_id_seq'::regclass);


--
-- Name: indication id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.indication ALTER COLUMN id SET DEFAULT nextval('public.indication_id_seq'::regclass);


--
-- Name: message_read id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.message_read ALTER COLUMN id SET DEFAULT nextval('public.message_read_id_seq'::regclass);


--
-- Name: note id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.note ALTER COLUMN id SET DEFAULT nextval('public.note_id_seq'::regclass);


--
-- Name: operating_room id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.operating_room ALTER COLUMN id SET DEFAULT nextval('public.operating_room_id_seq'::regclass);


--
-- Name: patient id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.patient ALTER COLUMN id SET DEFAULT nextval('public.patient_id_seq'::regclass);


--
-- Name: patient_tag id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.patient_tag ALTER COLUMN id SET DEFAULT nextval('public.patient_tag_id_seq'::regclass);


--
-- Name: payment id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payment ALTER COLUMN id SET DEFAULT nextval('public.payment_id_seq'::regclass);


--
-- Name: procedure id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.procedure ALTER COLUMN id SET DEFAULT nextval('public.procedure_id_seq'::regclass);


--
-- Name: surgery id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.surgery ALTER COLUMN id SET DEFAULT nextval('public.surgery_id_seq'::regclass);


--
-- Name: tag id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tag ALTER COLUMN id SET DEFAULT nextval('public.tag_id_seq'::regclass);


--
-- Name: transplant_image id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transplant_image ALTER COLUMN id SET DEFAULT nextval('public.transplant_image_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: appointment; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.appointment (id, patient_id, doctor_id, start_time, end_time, status, appointment_type, notes, waiting, checked_in_time, room, created_at) FROM stdin;
1	1	3	2025-11-25 09:00:00	2025-11-25 10:00:00	agendado	Particular	Consulta de retorno	f	\N	\N	2025-11-25 12:22:27.056876
2	2	3	2025-11-25 14:00:00	2025-11-25 15:00:00	confirmado	Particular	Primeira consulta	f	\N	\N	2025-11-25 12:22:27.056895
3	3	3	2025-11-25 09:00:00	2025-11-25 10:00:00	agendado	Consulta Inicial	\N	f	\N	\N	2025-11-25 12:23:38.322631
4	4	3	2025-11-25 10:30:00	2025-11-25 11:30:00	agendado	Retorno Botox	\N	f	\N	\N	2025-11-25 12:23:38.324779
5	5	3	2025-11-25 14:00:00	2025-11-25 15:00:00	agendado	Laser	\N	f	\N	\N	2025-11-25 12:23:38.325617
\.


--
-- Data for Name: chat_message; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.chat_message (id, sender_id, recipient_id, message, created_at, read) FROM stdin;
\.


--
-- Data for Name: cosmetic_procedure_plan; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.cosmetic_procedure_plan (id, note_id, procedure_name, planned_value, final_budget, was_performed, performed_date, follow_up_months, created_at) FROM stdin;
\.


--
-- Data for Name: doctor_preference; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.doctor_preference (id, user_id, color, layer_enabled, created_at) FROM stdin;
\.


--
-- Data for Name: follow_up_reminder; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.follow_up_reminder (id, patient_id, procedure_name, scheduled_date, reminder_type, status, notes, created_at) FROM stdin;
\.


--
-- Data for Name: hair_transplant; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.hair_transplant (id, note_id, norwood_classification, previous_transplant, transplant_location, case_type, number_of_surgeries, body_hair_needed, eyebrow_transplant, beard_transplant, frontal_transplant, crown_transplant, complete_transplant, complete_with_body_hair, surgical_planning, clinical_conduct, created_at) FROM stdin;
\.


--
-- Data for Name: indication; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.indication (id, note_id, procedure_id, indicated, performed, created_at) FROM stdin;
\.


--
-- Data for Name: message_read; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.message_read (id, message_id, user_id, read_at) FROM stdin;
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.note (id, patient_id, doctor_id, appointment_id, note_type, category, content, consultation_duration, created_at) FROM stdin;
\.


--
-- Data for Name: operating_room; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.operating_room (id, name, capacity, created_at) FROM stdin;
\.


--
-- Data for Name: patient; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.patient (id, name, phone, email, birth_date, cpf, address, patient_type, attention_note, created_at) FROM stdin;
1	Maria Silva	(11) 98765-4321	maria@example.com	\N	\N	\N	particular	\N	2025-11-25 12:22:27.030215
2	João Santos	(11) 91234-5678	joao@example.com	\N	\N	\N	particular	\N	2025-11-25 12:22:27.030245
3	João Silva	11999999999	\N	\N	\N	\N	particular	\N	2025-11-25 12:23:38.31208
4	Maria Santos	11988888888	\N	\N	\N	\N	unimed	\N	2025-11-25 12:23:38.316213
5	Carlos Oliveira	11977777777	\N	\N	\N	\N	particular	\N	2025-11-25 12:23:38.317266
\.


--
-- Data for Name: patient_tag; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.patient_tag (id, patient_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.payment (id, appointment_id, patient_id, total_amount, payment_method, installments, status, procedures, consultation_type, created_at, paid_at) FROM stdin;
\.


--
-- Data for Name: procedure; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.procedure (id, name, description, created_at) FROM stdin;
\.


--
-- Data for Name: surgery; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.surgery (id, date, start_time, end_time, patient_id, patient_name, procedure_id, procedure_name, doctor_id, operating_room_id, status, notes, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tag (id, name, color, created_at) FROM stdin;
\.


--
-- Data for Name: transplant_image; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.transplant_image (id, hair_transplant_id, image_type, file_path, description, created_at) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public."user" (id, email, password_hash, name, role, specialty, created_at) FROM stdin;
3	arthur@clinicabasiledemo.com	scrypt:32768:8:1$JRayCtB3BBVoGvdI$765e9550ea815e37bfb0987f7729e806477e7948cf59d6ec7d0f6a3ccf278a523635a7d8b23efd459fa848473e849f5237674ca4820e7f3785c808e176d4b17c	Dr. Arthur Basile	medico	\N	2025-11-25 15:50:34.103936
4	secretaria@clinicabasiledemo.com	scrypt:32768:8:1$Tw10FkwuU4UrlUVE$44d75c14c3bc74850fbcde05fdf37df2e996fc41475e831049f6f4687c1bbfc4d49e3ad2675df0d89caaf6c869ffebad302b677d0097c8472806fae723171a77	Secretária	secretaria	\N	2025-11-25 15:50:34.10396
\.


--
-- Name: appointment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.appointment_id_seq', 1, false);


--
-- Name: chat_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.chat_message_id_seq', 1, false);


--
-- Name: cosmetic_procedure_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.cosmetic_procedure_plan_id_seq', 1, false);


--
-- Name: doctor_preference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.doctor_preference_id_seq', 1, false);


--
-- Name: follow_up_reminder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.follow_up_reminder_id_seq', 1, false);


--
-- Name: hair_transplant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.hair_transplant_id_seq', 1, false);


--
-- Name: indication_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.indication_id_seq', 1, false);


--
-- Name: message_read_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.message_read_id_seq', 1, false);


--
-- Name: note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.note_id_seq', 1, false);


--
-- Name: operating_room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.operating_room_id_seq', 1, false);


--
-- Name: patient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.patient_id_seq', 1, false);


--
-- Name: patient_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.patient_tag_id_seq', 1, false);


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.payment_id_seq', 1, false);


--
-- Name: procedure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.procedure_id_seq', 1, false);


--
-- Name: surgery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.surgery_id_seq', 1, false);


--
-- Name: tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tag_id_seq', 1, false);


--
-- Name: transplant_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.transplant_image_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.user_id_seq', 4, true);


--
-- Name: message_read _message_user_uc; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.message_read
    ADD CONSTRAINT _message_user_uc UNIQUE (message_id, user_id);


--
-- Name: appointment appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_pkey PRIMARY KEY (id);


--
-- Name: chat_message chat_message_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_pkey PRIMARY KEY (id);


--
-- Name: cosmetic_procedure_plan cosmetic_procedure_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cosmetic_procedure_plan
    ADD CONSTRAINT cosmetic_procedure_plan_pkey PRIMARY KEY (id);


--
-- Name: doctor_preference doctor_preference_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.doctor_preference
    ADD CONSTRAINT doctor_preference_pkey PRIMARY KEY (id);


--
-- Name: doctor_preference doctor_preference_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.doctor_preference
    ADD CONSTRAINT doctor_preference_user_id_key UNIQUE (user_id);


--
-- Name: follow_up_reminder follow_up_reminder_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.follow_up_reminder
    ADD CONSTRAINT follow_up_reminder_pkey PRIMARY KEY (id);


--
-- Name: hair_transplant hair_transplant_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.hair_transplant
    ADD CONSTRAINT hair_transplant_pkey PRIMARY KEY (id);


--
-- Name: indication indication_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.indication
    ADD CONSTRAINT indication_pkey PRIMARY KEY (id);


--
-- Name: message_read message_read_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.message_read
    ADD CONSTRAINT message_read_pkey PRIMARY KEY (id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: operating_room operating_room_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.operating_room
    ADD CONSTRAINT operating_room_name_key UNIQUE (name);


--
-- Name: operating_room operating_room_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.operating_room
    ADD CONSTRAINT operating_room_pkey PRIMARY KEY (id);


--
-- Name: patient patient_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT patient_pkey PRIMARY KEY (id);


--
-- Name: patient_tag patient_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.patient_tag
    ADD CONSTRAINT patient_tag_pkey PRIMARY KEY (id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: procedure procedure_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.procedure
    ADD CONSTRAINT procedure_name_key UNIQUE (name);


--
-- Name: procedure procedure_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.procedure
    ADD CONSTRAINT procedure_pkey PRIMARY KEY (id);


--
-- Name: surgery surgery_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.surgery
    ADD CONSTRAINT surgery_pkey PRIMARY KEY (id);


--
-- Name: tag tag_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT tag_name_key UNIQUE (name);


--
-- Name: tag tag_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (id);


--
-- Name: transplant_image transplant_image_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transplant_image
    ADD CONSTRAINT transplant_image_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: idx_message_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_message_user ON public.message_read USING btree (message_id, user_id);


--
-- Name: idx_note_patient_appt_type; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_note_patient_appt_type ON public.note USING btree (patient_id, appointment_id, note_type);


--
-- Name: ix_follow_up_reminder_scheduled_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_follow_up_reminder_scheduled_date ON public.follow_up_reminder USING btree (scheduled_date);


--
-- Name: ix_message_read_message_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_message_read_message_id ON public.message_read USING btree (message_id);


--
-- Name: ix_message_read_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_message_read_user_id ON public.message_read USING btree (user_id);


--
-- Name: ix_payment_appointment_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_payment_appointment_id ON public.payment USING btree (appointment_id);


--
-- Name: ix_payment_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_payment_created_at ON public.payment USING btree (created_at);


--
-- Name: ix_payment_patient_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_payment_patient_id ON public.payment USING btree (patient_id);


--
-- Name: ix_surgery_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_surgery_date ON public.surgery USING btree (date);


--
-- Name: ix_surgery_doctor_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_surgery_doctor_id ON public.surgery USING btree (doctor_id);


--
-- Name: ix_surgery_operating_room_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_surgery_operating_room_id ON public.surgery USING btree (operating_room_id);


--
-- Name: ix_surgery_start_time; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_surgery_start_time ON public.surgery USING btree (start_time);


--
-- Name: ix_user_email; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_user_email ON public."user" USING btree (email);


--
-- Name: appointment appointment_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public."user"(id);


--
-- Name: appointment appointment_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patient(id);


--
-- Name: chat_message chat_message_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public."user"(id);


--
-- Name: chat_message chat_message_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public."user"(id);


--
-- Name: cosmetic_procedure_plan cosmetic_procedure_plan_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cosmetic_procedure_plan
    ADD CONSTRAINT cosmetic_procedure_plan_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id);


--
-- Name: doctor_preference doctor_preference_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.doctor_preference
    ADD CONSTRAINT doctor_preference_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: follow_up_reminder follow_up_reminder_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.follow_up_reminder
    ADD CONSTRAINT follow_up_reminder_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patient(id);


--
-- Name: hair_transplant hair_transplant_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.hair_transplant
    ADD CONSTRAINT hair_transplant_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id);


--
-- Name: indication indication_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.indication
    ADD CONSTRAINT indication_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id);


--
-- Name: indication indication_procedure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.indication
    ADD CONSTRAINT indication_procedure_id_fkey FOREIGN KEY (procedure_id) REFERENCES public.procedure(id);


--
-- Name: message_read message_read_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.message_read
    ADD CONSTRAINT message_read_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_message(id) ON DELETE CASCADE;


--
-- Name: message_read message_read_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.message_read
    ADD CONSTRAINT message_read_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: note note_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointment(id);


--
-- Name: note note_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public."user"(id);


--
-- Name: note note_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patient(id);


--
-- Name: patient_tag patient_tag_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.patient_tag
    ADD CONSTRAINT patient_tag_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patient(id);


--
-- Name: patient_tag patient_tag_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.patient_tag
    ADD CONSTRAINT patient_tag_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tag(id);


--
-- Name: payment payment_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointment(id);


--
-- Name: payment payment_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patient(id);


--
-- Name: surgery surgery_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.surgery
    ADD CONSTRAINT surgery_created_by_fkey FOREIGN KEY (created_by) REFERENCES public."user"(id);


--
-- Name: surgery surgery_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.surgery
    ADD CONSTRAINT surgery_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public."user"(id);


--
-- Name: surgery surgery_operating_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.surgery
    ADD CONSTRAINT surgery_operating_room_id_fkey FOREIGN KEY (operating_room_id) REFERENCES public.operating_room(id);


--
-- Name: surgery surgery_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.surgery
    ADD CONSTRAINT surgery_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patient(id);


--
-- Name: surgery surgery_procedure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.surgery
    ADD CONSTRAINT surgery_procedure_id_fkey FOREIGN KEY (procedure_id) REFERENCES public.procedure(id);


--
-- Name: surgery surgery_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.surgery
    ADD CONSTRAINT surgery_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public."user"(id);


--
-- Name: transplant_image transplant_image_hair_transplant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transplant_image
    ADD CONSTRAINT transplant_image_hair_transplant_id_fkey FOREIGN KEY (hair_transplant_id) REFERENCES public.hair_transplant(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

\unrestrict hRnEjLwxhdrICI3zvIbjXP0rY82HhNZIfRCyvTn1FPuLTs9ghdgJIYmaYL0JoOC

