BEGIN TRANSACTION;
CREATE TABLE appointment (
	id INTEGER NOT NULL, 
	patient_id INTEGER NOT NULL, 
	doctor_id INTEGER NOT NULL, 
	start_time DATETIME NOT NULL, 
	end_time DATETIME NOT NULL, 
	status VARCHAR(20), 
	appointment_type VARCHAR(20), 
	notes TEXT, 
	waiting BOOLEAN, 
	checked_in_time DATETIME, 
	room VARCHAR(50), 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(patient_id) REFERENCES patient (id), 
	FOREIGN KEY(doctor_id) REFERENCES user (id)
);
CREATE TABLE chat_message (
	id INTEGER NOT NULL, 
	sender_id INTEGER NOT NULL, 
	recipient_id INTEGER NOT NULL, 
	message TEXT NOT NULL, 
	created_at DATETIME, 
	read BOOLEAN, 
	PRIMARY KEY (id), 
	FOREIGN KEY(sender_id) REFERENCES user (id), 
	FOREIGN KEY(recipient_id) REFERENCES user (id)
);
CREATE TABLE cosmetic_procedure_plan (
	id INTEGER NOT NULL, 
	note_id INTEGER NOT NULL, 
	procedure_name VARCHAR(100) NOT NULL, 
	planned_value NUMERIC(10, 2), 
	final_budget NUMERIC(10, 2), 
	was_performed BOOLEAN, 
	performed_date DATETIME, 
	follow_up_months INTEGER, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(note_id) REFERENCES note (id)
);
CREATE TABLE doctor_preference (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	color VARCHAR(7), 
	layer_enabled BOOLEAN, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (user_id), 
	FOREIGN KEY(user_id) REFERENCES user (id)
);
CREATE TABLE follow_up_reminder (
	id INTEGER NOT NULL, 
	patient_id INTEGER NOT NULL, 
	procedure_name VARCHAR(100) NOT NULL, 
	scheduled_date DATE NOT NULL, 
	reminder_type VARCHAR(50), 
	status VARCHAR(20), 
	notes TEXT, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(patient_id) REFERENCES patient (id)
);
CREATE TABLE hair_transplant (
	id INTEGER NOT NULL, 
	note_id INTEGER NOT NULL, 
	norwood_classification VARCHAR(20), 
	previous_transplant VARCHAR(10), 
	transplant_location VARCHAR(50), 
	case_type VARCHAR(50), 
	number_of_surgeries INTEGER, 
	body_hair_needed BOOLEAN, 
	eyebrow_transplant BOOLEAN, 
	beard_transplant BOOLEAN, 
	frontal_transplant BOOLEAN, 
	crown_transplant BOOLEAN, 
	complete_transplant BOOLEAN, 
	complete_with_body_hair BOOLEAN, 
	surgical_planning TEXT, 
	clinical_conduct TEXT, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(note_id) REFERENCES note (id)
);
CREATE TABLE indication (
	id INTEGER NOT NULL, 
	note_id INTEGER NOT NULL, 
	procedure_id INTEGER NOT NULL, 
	indicated BOOLEAN, 
	performed BOOLEAN, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(note_id) REFERENCES note (id), 
	FOREIGN KEY(procedure_id) REFERENCES procedure (id)
);
CREATE TABLE message_read (
	id INTEGER NOT NULL, 
	message_id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	read_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT _message_user_uc UNIQUE (message_id, user_id), 
	FOREIGN KEY(message_id) REFERENCES chat_message (id) ON DELETE CASCADE, 
	FOREIGN KEY(user_id) REFERENCES user (id) ON DELETE CASCADE
);
CREATE TABLE note (
	id INTEGER NOT NULL, 
	patient_id INTEGER NOT NULL, 
	doctor_id INTEGER NOT NULL, 
	appointment_id INTEGER, 
	note_type VARCHAR(50) NOT NULL, 
	category VARCHAR(50), 
	content TEXT, 
	consultation_duration INTEGER, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(patient_id) REFERENCES patient (id), 
	FOREIGN KEY(doctor_id) REFERENCES user (id), 
	FOREIGN KEY(appointment_id) REFERENCES appointment (id)
);
CREATE TABLE operating_room (
	id INTEGER NOT NULL, 
	name VARCHAR(50) NOT NULL, 
	capacity INTEGER, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
CREATE TABLE patient (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	phone VARCHAR(20), 
	email VARCHAR(120), 
	birth_date DATE, 
	cpf VARCHAR(14), 
	address VARCHAR(200), 
	city VARCHAR(100), 
	mother_name VARCHAR(100), 
	referred_by VARCHAR(100), 
	occupation VARCHAR(100), 
	patient_type VARCHAR(50), 
	attention_note TEXT, 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE TABLE patient_tag (
	id INTEGER NOT NULL, 
	patient_id INTEGER NOT NULL, 
	tag_id INTEGER NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(patient_id) REFERENCES patient (id), 
	FOREIGN KEY(tag_id) REFERENCES tag (id)
);
CREATE TABLE payment (
	id INTEGER NOT NULL, 
	appointment_id INTEGER NOT NULL, 
	patient_id INTEGER NOT NULL, 
	total_amount NUMERIC(10, 2) NOT NULL, 
	payment_method VARCHAR(50) NOT NULL, 
	installments INTEGER, 
	status VARCHAR(20), 
	procedures JSON, 
	consultation_type VARCHAR(50), 
	created_at DATETIME, 
	paid_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(appointment_id) REFERENCES appointment (id), 
	FOREIGN KEY(patient_id) REFERENCES patient (id)
);
CREATE TABLE procedure (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	description TEXT, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
INSERT INTO "procedure" VALUES(1,'Ulthera','Ultrassom microfocado','2025-11-25 12:22:27.036909');
INSERT INTO "procedure" VALUES(2,'Morpheus8','Microagulhamento com radiofrequência','2025-11-25 12:22:27.036936');
INSERT INTO "procedure" VALUES(3,'Sculptra','Bioestimulador de colágeno','2025-11-25 12:22:27.036943');
INSERT INTO "procedure" VALUES(4,'Exilis','Radiofrequência','2025-11-25 12:22:27.036953');
INSERT INTO "procedure" VALUES(5,'Neo','Tratamento combinado','2025-11-25 12:22:27.036960');
INSERT INTO "procedure" VALUES(6,'Entone','Tonificação muscular','2025-11-25 12:22:27.036968');
CREATE TABLE surgery (
	id INTEGER NOT NULL, 
	date DATE NOT NULL, 
	start_time TIME NOT NULL, 
	end_time TIME NOT NULL, 
	patient_id INTEGER, 
	patient_name VARCHAR(100) NOT NULL, 
	procedure_id INTEGER, 
	procedure_name VARCHAR(200) NOT NULL, 
	doctor_id INTEGER NOT NULL, 
	operating_room_id INTEGER NOT NULL, 
	status VARCHAR(20), 
	notes TEXT, 
	created_by INTEGER NOT NULL, 
	updated_by INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(patient_id) REFERENCES patient (id), 
	FOREIGN KEY(procedure_id) REFERENCES procedure (id), 
	FOREIGN KEY(doctor_id) REFERENCES user (id), 
	FOREIGN KEY(operating_room_id) REFERENCES operating_room (id), 
	FOREIGN KEY(created_by) REFERENCES user (id), 
	FOREIGN KEY(updated_by) REFERENCES user (id)
);
CREATE TABLE tag (
	id INTEGER NOT NULL, 
	name VARCHAR(50) NOT NULL, 
	color VARCHAR(7), 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
INSERT INTO "tag" VALUES(1,'Pré-operatório','#ffc107','2025-11-25 12:22:27.041091');
INSERT INTO "tag" VALUES(2,'VIP','#6f42c1','2025-11-25 12:22:27.041115');
INSERT INTO "tag" VALUES(3,'Potencial Sculptra','#20c997','2025-11-25 12:22:27.041123');
INSERT INTO "tag" VALUES(4,'Retorno','#0dcaf0','2025-11-25 12:22:27.041128');
INSERT INTO "tag" VALUES(5,'Primeira Consulta','#fd7e14','2025-11-25 12:22:27.041135');
CREATE TABLE transplant_image (
	id INTEGER NOT NULL, 
	hair_transplant_id INTEGER NOT NULL, 
	image_type VARCHAR(50) NOT NULL, 
	file_path VARCHAR(255) NOT NULL, 
	description TEXT, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(hair_transplant_id) REFERENCES hair_transplant (id)
);
CREATE TABLE user (
	id INTEGER NOT NULL, 
	email VARCHAR(120) NOT NULL, 
	password_hash VARCHAR(200) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	role VARCHAR(20) NOT NULL, 
	specialty VARCHAR(50), 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
INSERT INTO "user" VALUES(1,'arthur@clinicabasiledemo.com','scrypt:32768:8:1$JRayCtB3BBVoGvdI$765e9550ea815e37bfb0987f7729e806477e7948cf59d6ec7d0f6a3ccf278a523635a7d8b23efd459fa848473e849f5237674ca4820e7f3785c808e176d4b17c','Dr. Arthur Basile','medico',NULL,'2025-11-25 12:22:27.046334');
INSERT INTO "user" VALUES(2,'secretaria@clinicabasiledemo.com','scrypt:32768:8:1$Tw10FkwuU4UrlUVE$44d75c14c3bc74850fbcde05fdf37df2e996fc41475e831049f6f4687c1bbfc4d49e3ad2675df0d89caaf6c869ffebad302b677d0097c8472806fae723171a77','Secretária','secretaria',NULL,'2025-11-25 12:22:27.046358');
CREATE UNIQUE INDEX ix_user_email ON user (email);
CREATE INDEX ix_surgery_date ON surgery (date);
CREATE INDEX ix_surgery_operating_room_id ON surgery (operating_room_id);
CREATE INDEX ix_surgery_doctor_id ON surgery (doctor_id);
CREATE INDEX ix_surgery_start_time ON surgery (start_time);
CREATE INDEX ix_follow_up_reminder_scheduled_date ON follow_up_reminder (scheduled_date);
CREATE INDEX idx_note_patient_appt_type ON note (patient_id, appointment_id, note_type);
CREATE INDEX ix_message_read_message_id ON message_read (message_id);
CREATE INDEX ix_message_read_user_id ON message_read (user_id);
CREATE INDEX idx_message_user ON message_read (message_id, user_id);
CREATE INDEX ix_payment_patient_id ON payment (patient_id);
CREATE INDEX ix_payment_appointment_id ON payment (appointment_id);
CREATE INDEX ix_payment_created_at ON payment (created_at);
COMMIT;
